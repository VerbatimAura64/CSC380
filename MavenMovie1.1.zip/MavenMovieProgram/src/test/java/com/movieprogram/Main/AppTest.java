
package com.movieprogram.Main;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.event.InputEvent;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileWriter;
import javax.imageio.ImageIO;
import java.io.IOException;

/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public AppTest( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested
     */
    public Test suite()
    {
        return new TestSuite( AppTest.class );
    }

    /**
     * Rigorous Test :-)
     * @throws java.awt.AWTException
     * @throws java.io.IOException
     */
    
    public void testApp() throws AWTException, IOException
    {
        Robot bot = new Robot();
        Testyo suf = new Testyo();
        bot.delay(3000);
        suf.setVisible(true);
        bot.delay(1000);
        suf.nameTextField.setText("Alex Pantaleev");
        bot.delay(1000);
        bot.mouseMove(suf.monthDOB.getLocationOnScreen().x+5,suf.monthDOB.getLocationOnScreen().y+5);
        bot.mousePress(InputEvent.BUTTON1_DOWN_MASK); bot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        bot.delay(1000);
            bot.mouseMove(suf.monthDOB.getLocationOnScreen().x+5,suf.monthDOB.getLocationOnScreen().y+70);
            bot.delay(1000);
            bot.mousePress(InputEvent.BUTTON1_DOWN_MASK); bot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        bot.delay(1000);
        bot.mouseMove(suf.dayDOB.getLocationOnScreen().x+5,suf.dayDOB.getLocationOnScreen().y+5);
        bot.mousePress(InputEvent.BUTTON1_DOWN_MASK); bot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        bot.delay(1000);
            bot.mouseMove(suf.dayDOB.getLocationOnScreen().x+5,suf.dayDOB.getLocationOnScreen().y+70);
            bot.delay(1000);
            bot.mousePress(InputEvent.BUTTON1_DOWN_MASK); bot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        bot.delay(1000);
        bot.mouseMove(suf.jComboBox3.getLocationOnScreen().x+5,suf.jComboBox3.getLocationOnScreen().y+5);
        bot.mousePress(InputEvent.BUTTON1_DOWN_MASK); bot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        bot.delay(1000);
            bot.mouseMove(suf.jComboBox3.getLocationOnScreen().x+5,suf.jComboBox3.getLocationOnScreen().y+70);
            bot.delay(1000);
            bot.mousePress(InputEvent.BUTTON1_DOWN_MASK); bot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        bot.delay(1000);
        suf.emailTextField.setText("alex@cs.oswego.edu");
        bot.delay(1000);
        suf.verifyEmailTextField.setText("alex@cs.oswego.edu");
        bot.delay(1000);
        suf.passwordField.setText("YouPassTheClass");
        bot.delay(1000);
        suf.verifyPasswordField.setText("YouPassTheClass");
        bot.delay(2000);
        bot.mouseMove(suf.emailCheckBox.getLocationOnScreen().x+2, suf.emailCheckBox.getLocationOnScreen().y+2);
        bot.mousePress(InputEvent.BUTTON1_DOWN_MASK); bot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        bot.delay(2000);
        bot.mouseMove(suf.termsCheckBox.getLocationOnScreen().x +2, suf.termsCheckBox.getLocationOnScreen().y +2);
        bot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        bot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        bot.mouseMove(suf.createButton.getLocationOnScreen().x +2, suf.createButton.getLocationOnScreen().y +2);
        bot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        bot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        bot.delay(2000);
    }
    
    /*
    public void testApp1() throws AWTException, IOException
    {
        Robot bot = new Robot();
        LoginClass lc = new LoginClass();
        lc.setVisible(true);
        bot.delay(1000);
        lc.loginTextField.setText("alex@cs.oswego.edu");
        lc.passwordField.setText("YouPassTheClass");
        
        bot.delay(1000);
        
        
    }
    */
        
    
   /* public void testApp2() throws AWTException, IOException
    {
        MainWindow mw = new MainWindow();
        Robot bot = new Robot();
        mw.setVisible(true);
        bot.delay(5000);
        mw.setVisible(true);
        bot.mouseMove(145,294);
        bot.delay(2000);
        bot.mousePress(InputEvent.BUTTON1_MASK);
        bot.mouseRelease(InputEvent.BUTTON1_MASK);
        mw.setVisible(false);
        bot.delay(2000);
        
    }
*/
    
//    public void testApp3() throws AWTException, IOException
//    {
//        Checkout check = new Checkout();
//        Robot bot = new Robot();
//        check.setVisible(true);
//        check.movieField.setText("John Wick");
//        //bot.delay(2000);
//        check.timeField.setText("4:30 - 7 pm");
//        //bot.delay(2000);
//        check.ticketsField.setText("4");
//        //bot.delay(2000);
//        check.softPriceField.setText("$17");
//        //bot.delay(2000);
//        check.loggedInAsField.setText("test@test.com");
//        bot.delay(2000);
//        check.nameField.setText("Brandon Williams");
//        bot.delay(2000);
//        check.accountNum.setText("1");
//        bot.delay(2000);
//        check.creditCard.setText("1234-5678-9000");
//        bot.delay(2000);
//        check.secNum.setText("007");
//        check.emailField.setText("bwilli21@oswego.edu");
//        check.ticketCost.setText("$17");
//        check.taxField.setText("$1.70");
//        check.finalPrice.setText("$18.70");
//        //check.nameOnCard.setText("Brandon S Williams");
//       // bot.delay(6000);
//        //assertEquals(check.nameOnCard.toString(), ("Brandon S Williams"));
//                // Click the button!
//        bot.mouseMove(800, 725);
//        bot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
//        bot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
//        bot.delay(2000);
//                // Click the other button!
//        bot.mouseMove(680, 400);
//        bot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
//        bot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
//        bot.delay(1000);
//        
//        
//        check.nameOnCard.setText("Brandon S Williams");
//       // assertEquals(check.nameOnCard,("Brandon S Williams"));
//        bot.delay(3000);
//        bot.mouseMove(800, 725);
//        bot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
//        bot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
//        bot.delay(1000);
//        
//        bot.mouseMove(680, 400);
//        bot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
//        bot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
//        bot.delay(3000);
//                
//        
//        
//        
//    }
//    
//    public void testApp4() throws AWTException, IOException {
//        Checkout check = new Checkout();
//        Robot bot = new Robot();
//        check.setVisible(true);
//        check.movieField.setText("John Wick");
//        //bot.delay(2000);
//        check.timeField.setText("4:30 - 7 pm");
//        //bot.delay(2000);
//        check.ticketsField.setText("4");
//        //bot.delay(2000);
//        check.softPriceField.setText("$17");
//        //bot.delay(2000);
//        check.loggedInAsField.setText("test@test.com");
//        check.nameField.setText("Brandon Williams");
//        check.accountNum.setText("1");
//        //bot.delay(2000);
//        check.creditCard.setText("1234-5678-9000");
//        //bot.delay(2000);
//        check.secNum.setText("007");
//        check.emailField.setText("bwilli21@oswego.edu");
//        check.ticketCost.setText("$17");
//        check.taxField.setText("$1.70");
//        check.finalPrice.setText("$18.70");
//        bot.delay(3000);
//        
//        
//        bot.mouseMove(800, 725);
//        bot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
//        bot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
//        bot.delay(3000);
//        
//                // Fix the  name.
//        bot.mouseMove(680, 400);
//        bot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
//        bot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
//        bot.delay(3000);
//        //check.nameOnCard.setText("Brandon S Williams");
//        check.nameOnCard.setText("11111");
//        bot.delay(1000);
//        bot.mouseMove(800, 725);
//        bot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
//        bot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
//        bot.delay(2000);
//        bot.mouseMove(680, 400);
//        bot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
//        bot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
////        check.nameOnCard.setText("Brandon S Williams");
////        bot.delay(3000);
////        bot.mouseMove(800, 725);
////        bot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
////        bot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
////        bot.delay(3000);
////        bot.mouseMove(680, 400);
////        bot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
////        bot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        
        
        
    }

